# Nile Residences Kigali

A Pen created on CodePen.io. Original URL: [https://codepen.io/MichaelMusembi/pen/KKOOpXo](https://codepen.io/MichaelMusembi/pen/KKOOpXo).

